import SectionHeader from "@/components/site/SectionHeader";

function Hourglass3D() {
  return (
    <svg
      viewBox="0 0 200 260"
      className="h-56 w-56 drop-shadow-[0_0_30px_rgba(212,176,64,0.35)]"
    >
      <defs>
        <linearGradient id="g" x1="0" x2="1">
          <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.4" />
          <stop offset="100%" stopColor="hsl(var(--primary))" />
        </linearGradient>
      </defs>
      <g fill="none" stroke="url(#g)" strokeWidth="6">
        <rect x="20" y="10" width="160" height="20" rx="10" />
        <rect x="20" y="230" width="160" height="20" rx="10" />
        <path d="M40 30 Q100 120 160 30" />
        <path d="M40 230 Q100 140 160 230" />
        <path
          className="origin-[100px_130px] animate-[spin_6s_linear_infinite]"
          d="M80 130 Q100 110 120 130 Q100 150 80 130 Z"
        />
      </g>
    </svg>
  );
}

export default function Ampulheta() {
  return (
    <section className="container py-20">
      <SectionHeader title="O tempo é o nosso ativo mais precioso." />
      <div className="mt-10 flex flex-col items-center gap-6">
        <Hourglass3D />
        <p className="max-w-2xl text-center text-muted-foreground">
          Cada dia fora do ambiente certo custa energia, direção e
          oportunidades. A NG existe para devolver clareza, ritmo e propósito ao
          empresário.
        </p>
      </div>
    </section>
  );
}
