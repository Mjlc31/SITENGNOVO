import SectionHeader from "@/components/site/SectionHeader";
import { Button } from "@/components/ui/button";

export default function CTAFinal() {
  return (
    <section className="container py-24" id="final">
      <SectionHeader
        title="A sua hora é agora."
        subtitle={
          <span>
            Não existe crescimento real na solidão. O que você precisa está a
            uma decisão de distância.
          </span>
        }
      />
      <div className="mt-8 flex flex-col sm:flex-row justify-center gap-3">
        <Button size="lg" asChild>
          <a href="#produtos">Quero o NG.PASS</a>
        </Button>
        <Button size="lg" variant="outline" asChild>
          <a href="#produtos">Quero o NG.MASTERS</a>
        </Button>
      </div>
    </section>
  );
}
