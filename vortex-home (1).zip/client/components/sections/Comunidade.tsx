import SectionHeader from "@/components/site/SectionHeader";

const testimonials = [
  {
    name: "Membro NG",
    text: "Em 3 meses, ganhei clareza e conexões que destravaram meu negócio.",
  },
  {
    name: "Empresária NG",
    text: "As provocações e o conselho estratégico mudaram minha operação.",
  },
  {
    name: "Empreendedor NG",
    text: "Negócios fechados dentro da rede pagaram o investimento rapidamente.",
  },
];

const stats = [
  { label: "Engajamento", value: "86%" },
  { label: "Membros ativos", value: "+240" },
  { label: "Negócios na rede", value: "+R$ 3,2M" },
];

export default function Comunidade() {
  return (
    <section className="container py-20">
      <SectionHeader
        title="Comunidade em Ação"
        subtitle="Depoimentos e resultados reais de quem vive o movimento."
      />
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {testimonials.map((t) => (
          <div
            key={t.name}
            className="rounded-xl border border-border bg-card p-6"
          >
            <p className="text-sm leading-relaxed">“{t.text}”</p>
            <div className="mt-4 text-xs text-muted-foreground">{t.name}</div>
          </div>
        ))}
      </div>
      <div className="mt-10 grid gap-6 sm:grid-cols-3">
        {stats.map((s) => (
          <div
            key={s.label}
            className="rounded-xl border border-border p-6 text-center"
          >
            <div className="text-4xl font-black text-primary">{s.value}</div>
            <div className="text-sm text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
