import SectionHeader from "@/components/site/SectionHeader";
import { Button } from "@/components/ui/button";

const events = [
  { title: "HUB.NG – Encontro mensal", date: "15 Out", location: "Maceió, AL" },
  {
    title: "Missão Nacional – São Paulo",
    date: "05 Nov",
    location: "São Paulo, SP",
  },
  { title: "Imersão Estratégica", date: "23 Nov", location: "Online" },
];

export default function Eventos() {
  return (
    <section id="eventos" className="container py-20">
      <SectionHeader title="Onde o extraordinário acontece." />
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {events.map((e) => (
          <div
            key={e.title}
            className="rounded-xl border border-border bg-card p-6 flex flex-col"
          >
            <div className="text-sm text-primary">{e.date}</div>
            <div className="mt-1 text-xl font-semibold">{e.title}</div>
            <div className="text-sm text-muted-foreground">{e.location}</div>
            <Button className="mt-6">Reserve seu lugar</Button>
          </div>
        ))}
      </div>
    </section>
  );
}
