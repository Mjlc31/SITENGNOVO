import { Button } from "@/components/ui/button";
import { Hourglass } from "lucide-react";

const VIDEO_ID = "dI4YwZ6MdUs";

export default function Hero() {
  return (
    <section
      className="relative min-h-[80vh] flex items-center"
      aria-label="Hero"
    >
      <div className="absolute inset-0 overflow-hidden">
        <iframe
          className="h-full w-full object-cover opacity-60"
          src={`https://www.youtube.com/embed/${VIDEO_ID}?autoplay=1&mute=1&loop=1&playlist=${VIDEO_ID}&rel=0&controls=0`}
          title="NG.Hub hero video"
          frameBorder="0"
          allow="autoplay; encrypted-media; fullscreen"
          allowFullScreen
        />
        <a
          href="https://www.youtube.com/watch?v=dI4YwZ6MdUs&ab_channel=NGHUB"
          target="_blank"
          rel="noopener noreferrer"
          className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent cursor-pointer flex"
          aria-label="NG.Hub video"
        />
      </div>
      <div className="container relative z-10 py-24">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-background/50 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
            <Hourglass className="h-3.5 w-3.5 text-primary animate-pulse" />O
            tempo é o nosso ativo
          </div>
          <h1 className="mt-5 text-4xl md:text-6xl font-extrabold leading-tight">
            O ponto de encontro dos jovens empresários do Brasil.
          </h1>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl">
            Mais que uma comunidade: um ecossistema de crescimento para quem não
            quer mais caminhar sozinho.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <Button size="lg" asChild>
              <a href="#produtos">Quero fazer parte</a>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="#metodo">Conheça o Método</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
