import SectionHeader from "@/components/site/SectionHeader";

const founders = [
  {
    name: "Arthur",
    role: "Fundador",
    bio: "Empresário e mentor de jovens líderes.",
  },
  {
    name: "Villar",
    role: "Co-fundador",
    bio: "Constrói pontes entre negócios e pessoas.",
  },
  {
    name: "João Andrade",
    role: "Diretor",
    bio: "Executor com foco em ritmo e resultado.",
  },
];

const areas = ["Diretoria", "Marketing", "Tesouraria", "Produção"];

export default function Lideranca() {
  return (
    <section id="lideranca" className="container py-20">
      <SectionHeader title="Quem guia o movimento." />

      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {founders.map((f) => (
          <div
            key={f.name}
            className="rounded-xl border border-border bg-card p-6"
          >
            <div className="h-16 w-16 rounded-full bg-gradient-to-br from-primary/40 to-primary/10 ring-2 ring-primary/40" />
            <div className="mt-3 text-xl font-semibold">
              <p>{f.name}</p>
            </div>
            <div className="text-sm text-primary">
              <p>{f.role}</p>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">{f.bio}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 text-center">
        <a href="#contato" className="text-sm text-primary underline">
          Conheça mais sobre a liderança NG
        </a>
      </div>
    </section>
  );
}
