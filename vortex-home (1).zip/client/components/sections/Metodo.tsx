import SectionHeader from "@/components/site/SectionHeader";
import useEmblaCarousel from "embla-carousel-react";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";

const steps = [
  { name: "BASE", desc: "Clareza e estrutura." },
  { name: "RITMO", desc: "Consistência e operação." },
  { name: "ESCALA", desc: "Crescimento consciente." },
  { name: "LEGADO", desc: "Impacto e sucessão." },
];

export default function Metodo() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ align: "start", loop: true });
  useEffect(() => {
    if (!emblaApi) return;
  }, [emblaApi]);

  return (
    <section id="metodo" className="container py-20">
      <SectionHeader
        title="O extraordinário nasce do básico bem-feito."
        subtitle="Descubra onde você está e o próximo passo para avançar com segurança."
      />

      <div className="mt-10 overflow-hidden" ref={emblaRef}>
        <div className="flex gap-6">
          {steps.map((s, idx) => (
            <div
              key={s.name}
              className="min-w-[260px] flex-1 rounded-xl border border-border bg-card p-6"
            >
              <div className="text-xs uppercase tracking-widest text-primary">
                Etapa {idx + 1}
              </div>
              <div className="mt-2 text-2xl font-bold">{s.name}</div>
              <p className="mt-2 text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-8 text-center">
        <Button size="lg" asChild>
          <a href="#diagnostico">Descubra em qual etapa você está</a>
        </Button>
      </div>
    </section>
  );
}
