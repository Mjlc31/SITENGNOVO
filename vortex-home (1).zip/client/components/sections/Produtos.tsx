import SectionHeader from "@/components/site/SectionHeader";
import { Button } from "@/components/ui/button";

const benefitsPass = [
  "Diagnóstico de negócios",
  "Hotseat mensal",
  "Networking e comunidade",
  "Acesso ao hub de oportunidades",
];

const benefitsMasters = [
  "Imersões exclusivas",
  "Networking high level",
  "Conselho estratégico",
  "Concierge de conexões",
  "Oportunidades de investimento",
];

export default function Produtos() {
  return (
    <section id="produtos" className="container py-20">
      <SectionHeader title="Escolha o seu nível de crescimento." />
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <div
          className="relative overflow-hidden rounded-2xl border border-yellow-900/30 bg-gradient-to-br from-white/3 to-card p-8 shadow-xl"
          style={{ borderColor: "rgba(180,162,100,0.18)" }}
        >
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage:
                "url('https://cdn.builder.io/api/v1/image/assets%2F85b1baf2104d49578f73f147e7b6f952%2Fb7a5f9221ef24f0d83c2ce22592f43ae?format=webp&width=1600')",
              backgroundSize: "cover",
              backgroundPosition: "center",
              mixBlendMode: "overlay",
            }}
          />

          <div className="absolute top-4 right-4 inline-flex items-center rounded-full bg-yellow-900/20 px-3 py-1 text-xs font-semibold text-primary">
            POPULAR
          </div>

          <h3 className="text-2xl font-extrabold">NG.PASS</h3>

          <div className="mt-2 flex items-baseline gap-3">
            <div className="text-4xl font-black">R$ 797</div>
            <div className="text-sm font-semibold text-muted-foreground">
              /mês
            </div>
          </div>

          <div className="text-sm text-muted-foreground mt-2">plano anual</div>

          <ul className="mt-6 space-y-3 text-sm">
            {benefitsPass.map((b) => (
              <li key={b} className="flex items-start gap-3">
                <span className="mt-1 h-2 w-2 rounded-full bg-primary shadow-[0_0_10px_rgba(180,162,100,0.25)]" />
                <span className="text-sm">{b}</span>
              </li>
            ))}
          </ul>

          <div className="mt-8">
            <Button
              className="w-full bg-primary text-primary-foreground border border-transparent hover:bg-primary/90"
              size="lg"
            >
              Quero o PASS
            </Button>
          </div>

          <div className="mt-4 text-xs text-muted-foreground">
            Inclui diagnóstico, hotseat e acesso ao hub de oportunidades.
          </div>
        </div>

        <div
          className="relative overflow-hidden rounded-2xl border border-yellow-900/30 bg-gradient-to-br from-white/3 to-card p-8 shadow-xl"
          style={{ borderColor: "rgba(180,162,100,0.18)" }}
        >
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage:
                "url('https://cdn.builder.io/api/v1/image/assets%2F85b1baf2104d49578f73f147e7b6f952%2Fb7a5f9221ef24f0d83c2ce22592f43ae?format=webp&width=1600')",
              backgroundSize: "cover",
              backgroundPosition: "center",
              mixBlendMode: "overlay",
            }}
          />

          <div className="absolute top-4 right-4 inline-flex items-center rounded-full bg-yellow-900/20 px-3 py-1 text-xs font-semibold text-primary">
            PREMIUM
          </div>

          <h3 className="text-2xl font-extrabold">NG.MASTERS</h3>

          <div className="mt-2 flex items-baseline gap-3">
            <div className="text-4xl font-black">R$ 45.000</div>
            <div className="text-sm font-semibold text-muted-foreground">
              /ano
            </div>
          </div>

          <div className="text-sm text-muted-foreground mt-2">negociável</div>

          <ul className="mt-6 space-y-3 text-sm">
            {benefitsMasters.map((b) => (
              <li key={b} className="flex items-start gap-3">
                <span className="mt-1 h-2 w-2 rounded-full bg-primary shadow-[0_0_10px_rgba(180,162,100,0.25)]" />
                <span className="text-sm">{b}</span>
              </li>
            ))}
          </ul>

          <div className="mt-8">
            <Button
              className="w-full bg-transparent text-primary border border-primary hover:bg-primary/10"
              size="lg"
            >
              Quero ser MASTER
            </Button>
          </div>

          <div className="mt-4 text-xs text-muted-foreground">
            Inclui imersões, networking high level e concierge.
          </div>
        </div>
      </div>
    </section>
  );
}
