import SectionHeader from "@/components/site/SectionHeader";

const PHOTOS = [
  "https://images.pexels.com/photos/1666471/pexels-photo-1666471.jpeg",
  "https://images.pexels.com/photos/1708909/pexels-photo-1708909.jpeg",
];

export default function Sobre() {
  return (
    <section id="sobre" className="container py-20">
      <SectionHeader
        title={<span>Um movimento que nasceu de um incômodo.</span>}
        subtitle={
          <span>
            Fundada em 2024, em Maceió (AL), a NG.Hub surgiu para resolver a
            solidão empreendedora. Hoje, conectamos jovens empresários com
            método, comunidade e experiências que transformam negócios e criam
            legados.
          </span>
        }
      />

      <div className="mt-12 grid gap-6 md:grid-cols-2">
        <div className="grid grid-cols-2 gap-4">
          {PHOTOS.map((src, i) => (
            <div
              key={i}
              className="group relative overflow-hidden rounded-xl border border-border"
            >
              <img
                src={src}
                alt="Encontros NG.Hub"
                className="aspect-[4/3] w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
          ))}
        </div>
        <div>
          <div className="relative pl-6">
            <div className="absolute left-0 top-1 h-full w-0.5 bg-gradient-to-b from-primary via-primary/40 to-transparent animate-pulse" />
            <ul className="space-y-8">
              <li>
                <div className="text-sm text-primary">2024</div>
                <div className="text-xl font-semibold">
                  Nasce a NG.Hub em Maceió (AL)
                </div>
                <p className="text-muted-foreground mt-1">
                  O início de um movimento para combater a solidão
                  empreendedora.
                </p>
              </li>
              <li>
                <div className="text-sm text-primary">2024-2025</div>
                <div className="text-xl font-semibold">
                  Primeiros encontros e método em evolução
                </div>
                <p className="text-muted-foreground mt-1">
                  Comunidade cresce com eventos, provocações e trocas reais.
                </p>
              </li>
              <li>
                <div className="text-sm text-primary">Agora</div>
                <div className="text-xl font-semibold">
                  Ecossistema de crescimento
                </div>
                <p className="text-muted-foreground mt-1">
                  Conexões, experiências e conselho estratégico para criar
                  legados.
                </p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
