import SectionHeader from "@/components/site/SectionHeader";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const steps = [
  {
    title: "Herói",
    desc: "Jovem empresário isolado.",
  },
  { title: "Problema", desc: "Solidão e falta de clareza." },
  { title: "Mentor", desc: "NG.Hub." },
  { title: "Jornada", desc: "Método, conexões, provocações." },
  {
    title: "Transformação",
    desc: "Empresário conectado, com visão, negócios e legado.",
  },
];

export default function Storytelling() {
  return (
    <section className="container py-20">
      <SectionHeader title="A jornada do jovem empresário." />
      <div className="mt-10 grid gap-6 md:grid-cols-5">
        {steps.map((s, i) => (
          <div
            key={s.title}
            className="rounded-xl border border-border p-6 bg-card"
          >
            <div className="text-xs uppercase tracking-widest text-primary">
              {String(i + 1).padStart(2, "0")}
            </div>
            <div className="mt-2 text-xl font-bold">{s.title}</div>
            <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 text-center">
        <Button asChild size="lg">
          <a href="#produtos" className="inline-flex items-center gap-2">
            Inicie sua jornada agora <ArrowRight className="h-4 w-4" />
          </a>
        </Button>
      </div>
    </section>
  );
}
