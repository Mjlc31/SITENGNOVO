import SectionHeader from "@/components/site/SectionHeader";

const items = [
  { title: "Servir.", text: "Colocar o outro em primeiro lugar." },
  { title: "Transformar.", text: "Negócios e pessoas na prática." },
  { title: "Transcender.", text: "Criar impacto que ultrapassa gerações." },
];

export default function Tripe() {
  return (
    <section id="tripe" className="container py-20">
      <SectionHeader eyebrow="Nosso DNA" title="Nosso DNA em 3 palavras." />
      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((i) => (
          <div
            key={i.title}
            className="group rounded-xl border border-border bg-card/50 p-6 transition-colors hover:bg-card"
          >
            <div className="text-2xl font-extrabold tracking-tight">
              {i.title}
            </div>
            <p className="mt-2 text-muted-foreground">{i.text}</p>
            <div className="mt-6 h-1 w-16 bg-primary/60 group-hover:bg-primary transition-colors" />
          </div>
        ))}
      </div>
    </section>
  );
}
