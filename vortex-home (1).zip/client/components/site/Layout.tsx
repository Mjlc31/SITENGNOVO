import { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Hourglass } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface LayoutProps {
  children: ReactNode;
}

const nav = [
  { href: "#sobre", label: "Sobre" },
  { href: "#tripe", label: "DNA" },
  { href: "#metodo", label: "Método" },
  { href: "#produtos", label: "Produtos" },
  { href: "#eventos", label: "Eventos" },
  { href: "#lideranca", label: "Liderança" },
];

export default function Layout({ children }: LayoutProps) {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-50 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="container mx-auto flex items-center justify-between py-3">
          <a
            href="#"
            className="flex items-center gap-2 font-extrabold tracking-tight text-xl"
          >
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <Hourglass className="h-4 w-4" />
            </span>
            NG.Hub
          </a>
          <nav className="hidden md:flex items-center gap-6">
            {nav.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                {n.label}
              </a>
            ))}
          </nav>
          <div className="hidden md:flex items-center gap-2">
            <Button asChild variant="ghost">
              <a href="#metodo">Conheça o Método</a>
            </Button>
            <Button asChild>
              <a href="#produtos">Quero fazer parte</a>
            </Button>
          </div>
          <button
            className="md:hidden p-2"
            onClick={() => setOpen((v) => !v)}
            aria-label="Abrir menu"
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        <div
          className={cn(
            "md:hidden border-t border-border",
            open ? "block" : "hidden",
          )}
        >
          <div className="container mx-auto py-3 flex flex-col gap-3">
            {nav.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="text-sm text-muted-foreground hover:text-foreground"
                onClick={() => setOpen(false)}
              >
                {n.label}
              </a>
            ))}
            <div className="flex gap-2">
              <Button asChild className="flex-1">
                <a href="#produtos">Quero fazer parte</a>
              </Button>
              <Button asChild variant="outline" className="flex-1">
                <a href="#metodo">Conheça o Método</a>
              </Button>
            </div>
          </div>
        </div>
      </header>
      <main>{children}</main>
      <footer className="border-t border-border mt-16">
        <div className="container mx-auto py-10 grid gap-6 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-2 font-bold text-lg">
              <Hourglass className="h-4 w-4" /> NG.Hub
            </div>
            <p className="mt-3 text-sm text-muted-foreground max-w-sm">
              Servir. Transformar. Transcender.
            </p>
          </div>
          <div className="flex flex-col gap-2 text-sm">
            <span className="font-semibold">Links</span>
            <a
              href="#sobre"
              className="text-muted-foreground hover:text-foreground"
            >
              Sobre
            </a>
            <a
              href="#metodo"
              className="text-muted-foreground hover:text-foreground"
            >
              Método
            </a>
            <a
              href="#produtos"
              className="text-muted-foreground hover:text-foreground"
            >
              Produtos
            </a>
            <a
              href="#eventos"
              className="text-muted-foreground hover:text-foreground"
            >
              Eventos
            </a>
            <a
              href="#contato"
              className="text-muted-foreground hover:text-foreground"
            >
              Contato
            </a>
          </div>
          <div className="text-sm">
            <span className="font-semibold">Siga</span>
            <div className="mt-2 flex gap-3 text-muted-foreground">
              <a
                href="#"
                aria-label="Instagram"
                className="hover:text-foreground"
              >
                Instagram
              </a>
              <a
                href="#"
                aria-label="LinkedIn"
                className="hover:text-foreground"
              >
                LinkedIn
              </a>
              <a
                href="#"
                aria-label="YouTube"
                className="hover:text-foreground"
              >
                YouTube
              </a>
            </div>
            <p className="mt-6 text-xs text-muted-foreground">
              © {new Date().getFullYear()} NG.Hub – Servir. Transformar.
              Transcender.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
