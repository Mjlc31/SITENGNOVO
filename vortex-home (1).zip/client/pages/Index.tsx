import Hero from "@/components/sections/Hero";
import Sobre from "@/components/sections/Sobre";
import Tripe from "@/components/sections/Tripe";
import Metodo from "@/components/sections/Metodo";
import Produtos from "@/components/sections/Produtos";
import Storytelling from "@/components/sections/Storytelling";
import Comunidade from "@/components/sections/Comunidade";
import Eventos from "@/components/sections/Eventos";
import Lideranca from "@/components/sections/Lideranca";
import Ampulheta from "@/components/sections/Ampulheta";
import CTAFinal from "@/components/sections/CTAFinal";

export default function Index() {
  return (
    <div>
      <Hero />
      <Sobre />
      <Tripe />
      <Metodo />
      <Produtos />
      <Storytelling />
      <Comunidade />
      <Eventos />
      <Lideranca />
      <Ampulheta />
      <CTAFinal />
      <div id="diagnostico" className="sr-only">
        diagnostico
      </div>
    </div>
  );
}
